Name:
  Reset Windows Update Tool.

Description:
  This tool reset the Windows Update Components.

Note:
  This tool cannot do it's job without administrative permissions.

URL:
  https://gallery.technet.microsoft.com/Reset-Windows-Update-Agent-d824badc (English).
  https://gallery.technet.microsoft.com/Restablecer-el-Agente-de-315edd3a (Spanish).

The tool command consists of the following files:
  Launcher.exe
  ResetWUEng.cmd
  License.pdf
  Help.chm

Author:
  Manuel Gil.

Version:
  10.5.3.1

Credits:
  Thank you for downloading this file.
  
  This tool was designed for your use, Enjoy!!.
